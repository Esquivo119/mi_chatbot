<?php
$host = "localhost";
$user = "abrahamv_Juan";   // cambia si tienes otro usuario
$pass = "2575Light999.";   // cambia si tienes clave en tu MySQL
$db   = "abrahamv_colegio";
$port = 3306;

$conn = new mysqli($host, $user, $pass, $db, $port);

if ($conn->connect_error) {
    die("❌ Error de conexión: " . $conn->connect_error);
}

// 🚨 Muy importante: forzar utf8mb4
if (!$conn->set_charset("utf8mb4")) {
    die("❌ Error al cargar utf8mb4: " . $conn->error);
}
?>
