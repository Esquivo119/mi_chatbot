<?php
// PG_solicitar.php
include("../BD/db.php");

// Capturar filtros
$busqueda_categoria = $_GET['categoria'] ?? '';
$busqueda_titulo    = $_GET['titulo'] ?? '';
$busqueda_autor     = $_GET['autor'] ?? '';
$busqueda_nivel     = $_GET['nivel'] ?? '';

// Construir consulta
$sql = "SELECT * FROM libros WHERE 1=1";
if ($busqueda_titulo !== '') {
    $t = $conn->real_escape_string($busqueda_titulo);
    $sql .= " AND titulo LIKE '%$t%'";
}
if ($busqueda_autor !== '') {
    $a = $conn->real_escape_string($busqueda_autor);
    $sql .= " AND autor LIKE '%$a%'";
}
if ($busqueda_nivel !== '') {
    $n = $conn->real_escape_string($busqueda_nivel);
    $sql .= " AND nivel = '$n'";
}
if ($busqueda_categoria !== '') {
    $c = $conn->real_escape_string($busqueda_categoria);
    $sql .= " AND categoria LIKE '%$c%'";
}
$sql .= " ORDER BY fecha_subida DESC";

$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Solicitar Materiales</title>
  <link rel="stylesheet" href="../css/stilo.css">
  <link rel="icon" type="image/png" href="../image/logo (2).png">

</head>
<body>
<header>
    <div class="logo">
      <img src="../image/logo (2).png" alt="Logo Colegio">
      <h1>I.E 4018 Abraham Valdelomar</h1>
    </div>
    <nav>
    <li><a href="../index.html">Inicio</a></li>
        <li><a href="../php/libro.php">Ver libros</a></li>
        <li><a href="../php/PG_solicitar.php">Contacto</a></li>
        <li><a href="../php/login.php">Administrador</a></li>
    </nav>
  </header>
  <h2 style="text-align:center;">📖 Solicitar Material</h2>

  <!-- Formulario de filtros -->
  <form method="GET" action="PG_solicitar.php" style="max-width:900px; margin:0 auto; text-align:center;">
    <input type="text" name="titulo" placeholder="Buscar por título" value="<?= htmlspecialchars($busqueda_titulo) ?>">
    <input type="text" name="autor" placeholder="Buscar por autor" value="<?= htmlspecialchars($busqueda_autor) ?>">

    <select name="nivel">
      <option value="">Todos los niveles</option>
      <option value="Primaria" <?= $busqueda_nivel==='Primaria'?'selected':'' ?>>Primaria</option>
      <option value="Secundaria" <?= $busqueda_nivel==='Secundaria'?'selected':'' ?>>Secundaria</option>
    </select>

    <select name="categoria">
      <option value="">Todas las categorías</option>
      <option <?= $busqueda_categoria==='LIBROS DE MATEMÁTICAS'?'selected':'' ?>>LIBROS DE MATEMÁTICAS</option>
      <option <?= $busqueda_categoria==='LIBROS DE QUÍMICA'?'selected':'' ?>>LIBROS DE QUÍMICA</option>
      <option <?= $busqueda_categoria==='FÍSICA Y CIENCIAS'?'selected':'' ?>>FÍSICA Y CIENCIAS</option>
      <option <?= $busqueda_categoria==='DESARROLLO PERSONAL'?'selected':'' ?>>DESARROLLO PERSONAL</option>
      <option <?= $busqueda_categoria==='CIUDADANÍA Y CÍVICA'?'selected':'' ?>>CIUDADANÍA Y CÍVICA</option>
      <option <?= $busqueda_categoria==='RELIGIÓN'?'selected':'' ?>>RELIGIÓN</option>
      <option <?= $busqueda_categoria==='EDUCACIÓN PARA EL TRABAJO'?'selected':'' ?>>EDUCACIÓN PARA EL TRABAJO</option>
      <option <?= $busqueda_categoria==='ARTE'?'selected':'' ?>>ARTE</option>
      <option <?= $busqueda_categoria==='EDUCACIÓN FÍSICA'?'selected':'' ?>>EDUCACIÓN FÍSICA</option>
      <option <?= $busqueda_categoria==='ÁREA LECTURAS'?'selected':'' ?>>ÁREA LECTURAS</option>
    </select>

    <button type="submit">🔍 Filtrar</button>
    <a href="PG_solicitar.php">🔁 Limpiar</a>
  </form>

  <!-- Resultados -->
  <div style="max-width:1000px; margin:20px auto;">
    <?php if ($result && $result->num_rows > 0): ?>
      <?php while ($row = $result->fetch_assoc()): ?>
        <div style="background:#fff; padding:12px; margin-bottom:12px; border-radius:8px; box-shadow:0 2px 5px rgba(0,0,0,.1);">
          <h3><?= htmlspecialchars($row['titulo']) ?></h3>
          <p><strong>Autor:</strong> <?= htmlspecialchars($row['autor']) ?> — <strong>Nivel:</strong> <?= htmlspecialchars($row['nivel']) ?> — <strong>Categoría:</strong> <?= htmlspecialchars($row['categoria']) ?></p>
          <a href="<?= htmlspecialchars($row['archivo']) ?>" target="_blank">📘 Ver PDF</a>

          <form method="POST" action="solicitar.php" style="display:inline-block; margin-left:10px;">
            <input type="hidden" name="libro_id" value="<?= $row['id'] ?>">
            <button type="submit">📩 Solicitar</button>
          </form>
        </div>
      <?php endwhile; ?>
    <?php else: ?>
      <p style="text-align:center; margin-top:20px;">⚠️ No se encontraron materiales con esos filtros.</p>
    <?php endif; ?>
  </div>
</body>
</html>
