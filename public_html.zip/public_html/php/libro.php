<?php
// materiales.php
include("../BD/db.php");

// Capturar filtros desde GET
$busqueda_titulo   = $_GET['titulo'] ?? '';
$busqueda_autor    = $_GET['autor'] ?? '';
$busqueda_nivel    = $_GET['nivel'] ?? '';
$busqueda_categoria= $_GET['categoria'] ?? '';

// Construir consulta segura (usamos real_escape_string)
$sql = "SELECT * FROM libros WHERE 1=1";
if ($busqueda_titulo !== '') {
    $t = $conn->real_escape_string($busqueda_titulo);
    $sql .= " AND titulo LIKE '%$t%'";
}
if ($busqueda_autor !== '') {
    $a = $conn->real_escape_string($busqueda_autor);
    $sql .= " AND autor LIKE '%$a%'";
}
if ($busqueda_nivel !== '') {
    // nivel en la BD es 'Primaria' o 'Secundaria' (según tu dump)
    $n = $conn->real_escape_string($busqueda_nivel);
    $sql .= " AND nivel = '$n'";
}
if ($busqueda_categoria !== '') {
    $c = $conn->real_escape_string($busqueda_categoria);
    // usamos LIKE por si hay variaciones de mayúsculas/acentos
    $sql .= " AND categoria LIKE '%$c%'";
}

$sql .= " ORDER BY fecha_subida DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Buscar Materiales - Biblioteca</title>
  <link rel="stylesheet" href="../css/stilo.css">
  <link rel="icon" type="image/png" href="../image/logo (2).png">


</head>
<body>
<header>
    <div class="logo">
    <img src="../image/logo (2).png" alt="Logo">
    <h1>I.E 4018 Abraham Valdelomar</h1>
    </div>
    <nav>
    <li><a href="../index.html">Inicio</a></li>
<li><a href="libro.php">Ver libros</a></li>
<li><a href="PG_solicitar.php">Contacto</a></li>
<li><a href="login.php">Administrador</a></li>


    </nav>
  </header>

  <!-- Header (si lo usas) -->
  <?php if (file_exists('header.php')) include 'header.php'; ?>

  <h2 style="text-align:center; margin-top:18px;">📚 Buscar Materiales</h2>

  <!-- Buscador + Sugerencias -->
  <div class="top-section">
    <div class="buscador">
      <form method="GET" action="materiales.php">
        <input type="text" name="titulo" placeholder="Buscar por título..." value="<?= htmlspecialchars($busqueda_titulo) ?>">
        <input type="text" name="autor" placeholder="Buscar por autor..." value="<?= htmlspecialchars($busqueda_autor) ?>">
        <div style="display:flex; gap:8px;">
          <select name="nivel">
            <option value="">Todos los niveles</option>
            <option value="Primaria" <?= $busqueda_nivel === 'Primaria' ? 'selected' : '' ?>>Primaria</option>
            <option value="Secundaria" <?= $busqueda_nivel === 'Secundaria' ? 'selected' : '' ?>>Secundaria</option>
          </select>

          <select name="categoria">
            <option value="">Todas las categorías</option>
            <option <?= $busqueda_categoria === 'LIBROS DE MATEMÁTICAS' ? 'selected' : '' ?>>LIBROS DE MATEMÁTICAS</option>
            <option <?= $busqueda_categoria === 'LIBROS DE QUÍMICA' ? 'selected' : '' ?>>LIBROS DE QUÍMICA</option>
            <option <?= $busqueda_categoria === 'FÍSICA Y CIENCIAS' ? 'selected' : '' ?>>FÍSICA Y CIENCIAS</option>
            <option <?= $busqueda_categoria === 'DESARROLLO PERSONAL' ? 'selected' : '' ?>>DESARROLLO PERSONAL</option>
            <option <?= $busqueda_categoria === 'CIUDADANÍA Y CÍVICA' ? 'selected' : '' ?>>CIUDADANÍA Y CÍVICA</option>
            <option <?= $busqueda_categoria === 'RELIGIÓN' ? 'selected' : '' ?>>RELIGIÓN</option>
            <option <?= $busqueda_categoria === 'EDUCACIÓN PARA EL TRABAJO' ? 'selected' : '' ?>>EDUCACIÓN PARA EL TRABAJO</option>
            <option <?= $busqueda_categoria === 'ARTE' ? 'selected' : '' ?>>ARTE</option>
            <option <?= $busqueda_categoria === 'EDUCACIÓN FÍSICA' ? 'selected' : '' ?>>EDUCACIÓN FÍSICA</option>
            <option <?= $busqueda_categoria === 'ÁREA LECTURAS' ? 'selected' : '' ?>>ÁREA LECTURAS</option>
          </select>
        </div>
        <div style="margin-top:10px;">
          <button type="submit" class="btn-buscar">🔍 Buscar</button>
          <a href="libro.php" style="margin-left:8px; color:#00509e; text-decoration:none;">🔁 Limpiar</a>
        </div>
      </form>
    </div>

    <div class="sugerencias">
      <h3>💡 Sugerencias</h3>
      <textarea id="nuevaSugerencia" placeholder="Escribe un libro que quieras recomendar..." style="width:100%; padding:8px; border-radius:6px; border:1px solid #ccc;"></textarea>
      <button id="btnSugerir" style="margin-top:8px; background:#ff9800; color:#fff; padding:8px 12px; border:none; border-radius:6px; cursor:pointer;">Enviar sugerencia</button>

      <div id="listaSugerencias" style="margin-top:12px;"></div>
    </div>
  </div>

  <!-- Resultados -->
  <div id="resultados">
    <?php if ($result && $result->num_rows > 0): ?>
      <?php while ($row = $result->fetch_assoc()): ?>
        <div class="material">
          <div class="info">
            <h3><?= htmlspecialchars($row['titulo']) ?></h3>
            <p><strong>Autor:</strong> <?= htmlspecialchars($row['autor']) ?></p>
            <p><strong>Nivel:</strong> <?= htmlspecialchars($row['nivel']) ?> — <strong>Categoría:</strong> <?= htmlspecialchars($row['categoria']) ?></p>
            

            <div class="acciones" style="margin-top:8px;">
              <a class="btn-ver" href="<?= htmlspecialchars($row['archivo']) ?>" target="_blank">📖 Ver PDF</a>

              <form method="POST" action="solicitar.php" style="display:inline-block; margin-left:8px;">
                <input type="hidden" name="libro_id" value="<?= $row['id'] ?>">
                <button type="submit" class="btn-solicitar">Solicitar</button>
              </form>
            </div>
          </div>

          <!-- Comentarios locales (localStorage) -->
          
        </div>
      <?php endwhile; ?>
    <?php else: ?>
      <div style="background:#fff;padding:20px;border-radius:10px;text-align:center;margin:0 auto;max-width:800px;">
        ⚠️ No se encontraron materiales para los filtros seleccionados.
      </div>
    <?php endif; ?>
  </div>

  <?php if (file_exists('footer.php')) include 'footer.php'; ?>

  <script>
    // Sugerencias en localStorage
    function cargarSugerencias() {
      const lista = document.getElementById('listaSugerencias');
      lista.innerHTML = '';
      const sugerencias = JSON.parse(localStorage.getItem('sugerencias')) || [];
      sugerencias.forEach(s => {
        const d = document.createElement('div');
        d.className = 'sugerencia';
        d.textContent = '📘 ' + s;
        lista.appendChild(d);
      });
    }
    document.getElementById('btnSugerir').addEventListener('click', () => {
      const t = document.getElementById('nuevaSugerencia').value.trim();
      if (!t) return;
      const sugerencias = JSON.parse(localStorage.getItem('sugerencias')) || [];
      sugerencias.unshift(t);
      localStorage.setItem('sugerencias', JSON.stringify(sugerencias.slice(0,50)));
      document.getElementById('nuevaSugerencia').value = '';
      cargarSugerencias();
    });
    cargarSugerencias();

    // Comentarios por libro (localStorage), key: comentarios_{id}
    function mostrarComentarios(id) {
      const cont = document.getElementById('comentarios-' + id);
      cont.innerHTML = '';
      const comentarios = JSON.parse(localStorage.getItem('comentarios')) || {};
      (comentarios[id] || []).forEach(c => {
        const div = document.createElement('div');
        div.className = 'sugerencia';
        div.textContent = c;
        cont.appendChild(div);
      });
    }

    function agregarComentario(id) {
      const txt = document.getElementById('nuevoComentario-' + id);
      const val = txt.value.trim();
      if (!val) return;
      const comentarios = JSON.parse(localStorage.getItem('comentarios')) || {};
      if (!comentarios[id]) comentarios[id] = [];
      comentarios[id].unshift(val);
      localStorage.setItem('comentarios', JSON.stringify(comentarios));
      txt.value = '';
      mostrarComentarios(id);
    }

    // Inicializar comentarios para cada libro mostrado
    document.addEventListener('DOMContentLoaded', () => {
      <?php
        // Genera llamadas JS para mostrar comentarios de cada libro en la página actual
        if ($result && $result->num_rows > 0) {
          mysqli_data_seek($result, 0); // volver al inicio
          while ($r = $result->fetch_assoc()) {
            echo "mostrarComentarios(" . intval($r['id']) . ");\n";
          }
        }
      ?>
    });
  </script>
</body>
</html>
