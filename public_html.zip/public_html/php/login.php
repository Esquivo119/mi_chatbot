<?php
session_start();
include("../BD/db.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $usuario = $_POST['usuario'];
    $password = $_POST['clave'];

    $sql = "SELECT * FROM usuarios WHERE usuario = ? AND password = ?";
    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        die("❌ Error en la consulta SQL: " . $conn->error);
    }

    $stmt->bind_param("ss", $usuario, md5($password));
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        $_SESSION["docente"] = $usuario;
        header("Location: ../crud/libro_crud.php");

        exit();
    } else {
        $error = "Usuario o clave incorrectos.";
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Login - Colegio</title>
  <link rel="stylesheet" href="../css/login.css">
    <link rel="icon" type="image/png" href="../image/logo (2).png">
</head>
<body>
  <header>
    <div class="logo">
    <img src="../image/logo (2).png" alt="Logo">
    <h1>I.E 4018 Abraham Valdelomar</h1>
    </div>
    <nav>
    <li><a href="../index.html">Inicio</a></li>
<li><a href="libro.php">Ver libros</a></li>
<li><a href="PG_solicitar.php">Contacto</a></li>
<li><a href="login.php">Administrador</a></li>


    </nav>
  </header>
  <main class="login-content">
    <section class="left-area">
      <img src="../image/logo (2).png" alt="Logo Grande" class="logo-grande">
      <p class="nombre-colegio">I.E 4018 Abraham Valdelomar</p>
    </section>
    <section class="right-area">
      <div class="login-box">
        <h2><span class="emoji">🔑</span> Acceso Docentes</h2>
        <form method="POST" action="">
          <label >Usuario:</label>
          <input type="text" id="usuario" name="usuario" placeholder="Ingresa tu usuario" required>
          <label >Clave:</label>
          <input type="password" id="clave" name="clave" placeholder="Ingresa tu clave" required>
          <button type="submit">Ingresar</button>
        </form>
      </div>
    </section>
  </main>
</body>
</html> 