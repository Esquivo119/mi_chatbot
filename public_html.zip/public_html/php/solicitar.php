
<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php';

// 🔹 Conexión a la BD en Hostinger
$host = "localhost"; 
$user = "abrahamv_Juan";    // tu usuario MySQL en H1
$pass = "2575Light999.";    // tu contraseña MySQL en H1
$db   = "abrahamv_colegio"; // nombre de tu BD
$port = 3306;

$conn = new mysqli($host, $user, $pass, $db, $port);

if ($conn->connect_error) {
    die("❌ Error de conexión: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['libro_id'])) {
    $libro_id = intval($_POST['libro_id']);

    // 🔹 Obtener datos del libro
    $stmt = $conn->prepare("SELECT titulo, autor, categoria FROM libros WHERE id=?");
    $stmt->bind_param("i", $libro_id);
    $stmt->execute();
    $stmt->bind_result($titulo, $autor, $categoria);
    $stmt->fetch();
    $stmt->close();

    // 🔹 Insertar en la tabla solicitudes
    $sql = "INSERT INTO solicitudes (libro_id, titulo, autor, categoria, fecha_solicitud) 
            VALUES (?, ?, ?, ?, NOW())";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("isss", $libro_id, $titulo, $autor, $categoria);
    $stmt->execute();
    $stmt->close();

    // 🔹 Enviar correo con PHPMailer usando el servidor del dominio
    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host = 'mail.abrahamvaldelomar.pro';  // Servidor SMTP de tu hosting
        $mail->SMTPAuth = true;
        $mail->Username = 'biblioteca@abrahamvaldelomar.pro'; // tu correo del dominio
        $mail->Password = '2575Light999.';                   // contraseña del correo
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;  // cifrado TLS
        $mail->Port = 587;

        // Remitente y destinatarios
        $mail->setFrom('biblioteca@abrahamvaldelomar.pro', 'Sistema Biblioteca');
        $mail->addAddress('biblioteca@abrahamvaldelomar.pro', 'Bibliotecario'); 
        $mail->addAddress('bibliotecaform@gmail.com', 'Respaldo Gmail'); // 👈 copia a Gmail

        // Contenido del correo
        $mail->isHTML(true);
        $mail->Subject = "Nueva solicitud de libro";
        $mail->Body = "
            <h3>📚 Se registró una nueva solicitud de libro</h3>
            <p><b>Título:</b> $titulo</p>
            <p><b>Autor:</b> $autor</p>
            <p><b>Categoría:</b> $categoria</p>
            <p><b>Fecha y hora:</b> " . date("Y-m-d H:i:s") . "</p>
        ";

        $mail->send();
        echo "<script>alert('✅ Solicitud enviada y registrada con éxito.'); window.location='PG_solicitar.php';</script>";
    } catch (Exception $e) {
        echo "❌ Error al enviar el correo: {$mail->ErrorInfo}";
    }
}
?>


