<?php
session_start();
if (!isset($_SESSION["docente"])) {
    header("Location: ../php/login.php");
    exit();
}
include("../BD/db.php");

// Capturar filtros desde GET
$busqueda_titulo   = $_GET['titulo'] ?? '';
$busqueda_autor    = $_GET['autor'] ?? '';
$busqueda_nivel    = $_GET['nivel'] ?? '';
$busqueda_categoria= $_GET['categoria'] ?? '';

// Construir consulta segura
$sql = "SELECT * FROM libros WHERE 1=1";
if ($busqueda_titulo !== '') {
    $t = $conn->real_escape_string($busqueda_titulo);
    $sql .= " AND titulo LIKE '%$t%'";
}
if ($busqueda_autor !== '') {
    $a = $conn->real_escape_string($busqueda_autor);
    $sql .= " AND autor LIKE '%$a%'";
}
if ($busqueda_nivel !== '') {
    $n = $conn->real_escape_string($busqueda_nivel);
    $sql .= " AND nivel = '$n'";
}
if ($busqueda_categoria !== '') {
    $c = $conn->real_escape_string($busqueda_categoria);
    $sql .= " AND categoria LIKE '%$c%'";
}
$sql .= " ORDER BY id DESC";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>CRUD Materiales</title>
<link rel="stylesheet" href="../css/styleCr.css">
<link rel="icon" type="image/png" href="../image/logo (2).png">
<style>
/* Filtros */
.filtros {
  margin:20px auto;
  max-width:800px;
  background:#fff;
  padding:15px;
  border-radius:8px;
  box-shadow:0 1px 4px rgba(0,0,0,0.1);
}
.filtros input, .filtros select {
  margin:5px;
  padding:6px;
  border-radius:4px;
  border:1px solid #ccc;
}
.filtros button {
  margin-left:5px;
  padding:6px 12px;
  background:#00509e;
  color:#fff;
  border:none;
  border-radius:4px;
  cursor:pointer;
}
.filtros a {
  margin-left:8px;
  text-decoration:none;
  color:#ff5722;
}
</style>
</head>
<body>
<header>
    <div class="logo">
      <img src="../image/logo (2).png" alt="Logo Colegio">
      <h1>I.E 4018 Abraham Valdelomar</h1>
    </div>
    <nav>
      <li><a href="../index.html">Inicio</a></li>
      <li><a href="../php/libro.php">Ver libros</a></li>
      <li><a href="../php/PG_solicitar.php">Contacto</a></li>
      <li><a href="../php/login.php">Administrador</a></li>
    </nav>
</header>

<div class="crud-container">
    <h2>Gestión de Materiales</h2>
    <a href="libro_nuevo.php" class="btn-add">➕ Agregar Material</a>

    <!-- 🔎 Motor de búsqueda -->
    <form method="GET" class="filtros">
        <input type="text" name="titulo" placeholder="Buscar por título..." value="<?= htmlspecialchars($busqueda_titulo) ?>">
        <input type="text" name="autor" placeholder="Buscar por autor..." value="<?= htmlspecialchars($busqueda_autor) ?>">

        <select name="nivel">
          <option value="">Todos los niveles</option>
          <option value="Primaria" <?= $busqueda_nivel === 'Primaria' ? 'selected' : '' ?>>Primaria</option>
          <option value="Secundaria" <?= $busqueda_nivel === 'Secundaria' ? 'selected' : '' ?>>Secundaria</option>
        </select>

        <select name="categoria">
          <option value="">Todas las categorías</option>
<option <?= $busqueda_categoria === 'LIBROS DE MATEMÁTICAS' ? 'selected' : '' ?>>LIBROS DE MATEMÁTICAS</option>
<option <?= $busqueda_categoria === 'LIBROS DE QUÍMICA, FÍSICA Y CIENCIAS' ? 'selected' : '' ?>>LIBROS DE QUÍMICA, FÍSICA Y CIENCIAS</option>
<option <?= $busqueda_categoria === 'LIBROS DE COMUNICACION' ? 'selected' : '' ?>>LIBROS DE COMUNICACION</option>
<option <?= $busqueda_categoria === 'OBRAS' ? 'selected' : '' ?>>OBRAS</option>
<option <?= $busqueda_categoria === 'LIBROS DE HISTORIA Y GEOGRAFIA' ? 'selected' : '' ?>>LIBROS DE HISTORIA Y GEOGRAFIA</option>
<option <?= $busqueda_categoria === 'LIBROS DE DESARROLLO PERSONAL, CIUDADANIA Y CIVICA' ? 'selected' : '' ?>>LIBROS DE DESARROLLO PERSONAL, CIUDADANIA Y CIVICA</option>
<option <?= $busqueda_categoria === 'LIBROS DE RELIGION' ? 'selected' : '' ?>>LIBROS DE RELIGION</option>
<option <?= $busqueda_categoria === 'LIBROS EDUCACION PARA EL TRABAJO' ? 'selected' : '' ?>>LIBROS EDUCACION PARA EL TRABAJO</option>
<option <?= $busqueda_categoria === 'ÁRTE' ? 'selected' : '' ?>>ÁRTE</option>
<option <?= $busqueda_categoria === 'LIBROS DE INGLES' ? 'selected' : '' ?>>LIBROS DE INGLES</option>
<option <?= $busqueda_categoria === 'EDUCACION FISICA' ? 'selected' : '' ?>>EDUCACION FISICA</option>
<option <?= $busqueda_categoria === 'LIBROS DE COMPUTACION' ? 'selected' : '' ?>>LIBROS DE COMPUTACION</option>
<option <?= $busqueda_categoria === 'LIBROS TUTORIA Y GUIAS' ? 'selected' : '' ?>>LIBROS TUTORIA Y GUIAS</option>
<option <?= $busqueda_categoria === 'LIBROS DE LECTURAS' ? 'selected' : '' ?>>LIBROS DE LECTURAS</option>

        </select>

        <button type="submit">🔍 Buscar</button>
        <a href="libro_crud.php">🔁 Limpiar</a>
    </form>

    <!-- 📋 Tabla CRUD -->
    <table class="crud-table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Autor</th>
                <th>Nivel</th>
                <th>Categoría</th>
                <th>Archivo PDF</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if($result && $result->num_rows > 0){
                while($row = $result->fetch_assoc()){
                    echo "<tr>";
                    echo "<td>".intval($row['id'])."</td>";
                    echo "<td>".htmlspecialchars($row['titulo'])."</td>";
                    echo "<td>".htmlspecialchars($row['autor'])."</td>";
                    echo "<td>".htmlspecialchars($row['nivel'])."</td>";
                    echo "<td>".htmlspecialchars($row['categoria'])."</td>";
                    echo "<td><a href='".htmlspecialchars($row['archivo'])."' target='_blank'>Abrir PDF</a></td>";
                    echo "<td>
                            <a class='btn-edit' href='libro_editar.php?id=".intval($row['id'])."'>Editar</a>
                            <a class='btn-delete' href='libro_eliminar.php?id=".intval($row['id'])."' onclick=\"return confirm('¿Seguro que quieres eliminar este material?');\">Eliminar</a>
                          </td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='7' style='text-align:center;'>⚠️ No se encontraron materiales con esos filtros.</td></tr>";
            }
            ?>
        </tbody>
    </table>
</div>
</body>
</html>
