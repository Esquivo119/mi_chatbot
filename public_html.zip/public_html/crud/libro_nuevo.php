<?php
session_start();
if (!isset($_SESSION["docente"])) {
    header("Location: ../php/login.php");
    exit();
}
include("../BD/db.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $titulo    = $_POST['nombre'];   // cambio de nombre → en DB es "titulo"
    $autor     = $_POST['autor'];
    $nivel     = $_POST['nivel'];
    $categoria = $_POST['categoria'];
    $archivo   = $_POST['pdf'];      // en DB es "archivo"

    $sql = "INSERT INTO libros (titulo, autor, nivel, categoria, archivo) VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        die("❌ Error en la consulta SQL: " . $conn->error);
    }

    $stmt->bind_param("sssss", $titulo, $autor, $nivel, $categoria, $archivo);
    $stmt->execute();

    header("Location: libro_crud.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Agregar Libro</title>
  <link rel="stylesheet" href="../css/styleCr.css">
  </head>
<body>
<header>
    <div class="logo">
      <img src="../image/logo (2).png" alt="Logo Colegio">
      <h1>I.E 4018 Abraham Valdelomar</h1>
    </div>
    <nav>
    <li><a href="../index.html">Inicio</a></li>
        <li><a href="../php/libro.php">Ver libros</a></li>
        <li><a href="../php/PG_solicitar.php">Contacto</a></li>
        <li><a href="../php/login.php">Administrador</a></li>
    </nav>
  </header>
  <h2>Agregar Libro</h2>
  <form method="POST">
    <label>Título:</label><br><input type="text" name="nombre" required><br>
    <label>Autor:</label><br><input type="text" name="autor" required><br>
    <label>Nivel:</label><br>
    <select name="nivel" required>
      <option>Primaria</option>
      <option>Secundaria</option>
    </select><br>
    <label>Categoría:</label><br>
    <select name="categoria" required>
      <option>LIBROS DE MATEMÁTICAS</option>
      <option>LIBROS DE QUÍMICA, FÍSICA Y CIENCIAS</option>
      <option>LIBROS DE COMUNICACION</option>
      <option>OBRAS</option>
      <option>LIBROS DE HISTORIA Y GEOGRAFIA</option>
      <option>LIBROS DE DESARROLLO PERSONAL, CIUDADANIA Y CIVICA</option>
      <option>LIBROS DE RELIGION</option>
      <option>LIBROS EDUCACION PARA EL TRABAJO</option>
      <option>ÁRTE</option>
      <option>LIBROS DE INGLES</option>
      <option>EDUCACION FISICA</option>
      <option>LIBROS DE COMPUTACION</option>
      <option>LIBROS TUTORIA Y GUIAS</option>
      <option>LIBROS DE LECTURAS</option>
    </select><br>
    <label>Archivo PDF (URL o ruta):</label><br><input type="text" name="pdf"><br><br>
    <button type="submit">Guardar</button>
  </form>
  <p><a href="libro_crud.php">⬅ Volver</a></p>
</body>
</html>
